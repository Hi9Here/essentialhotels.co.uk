<?php
/*
Template Name: Booking Was Not Done
*/
?>



<?php get_header(); ?>
       
    <div id="content" class="page col-full">
          <div id="main" class="fullwidth">                 
                    <div class="entry">
                          <div class="backimage" style="background-image:url(http://essentialworld.travel/wp-content/uploads/2012/11/Lost-in-Boskenna-Woods-980-V3.jpg); height: 740px;" margin-top: 0px;>
<div style="
     height: 430px;
     width: 400px;
     font-family: Tahoma, Geneva, sans-serif;
     font-size: 18px;
     color: #FFF;
     padding-top: 50px;
     margin-left: 500px;
     background: #999999;
     opacity: 0.9;"
<div>
<div class="floatingtext" style="margin: 20px; opacity: 1.0;">
     <h1 style="color: white;">Booking Incomplete</h1>
Not to worry we have your details and a member of the Essential Team will be contacting back to complete the process. If you wish to call use the number below
<div class="clicktocall" style="font-size: 30px; margin-top: 20px; margin-left: 70px">
<a href=”tel:0118 971 4700″>0118 971 4700</a>
</div>

</div>

</div></div></div></div>

  
                                                            
          </div><!-- /#main -->
          
    </div><!-- /#content -->