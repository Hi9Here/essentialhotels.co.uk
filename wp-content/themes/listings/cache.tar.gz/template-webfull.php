<?php
/*
Template Name: Full Width Back Image
*/
?>



<?php get_header(); ?>
       
    <div id="content" class="page col-full">
          <div id="main" class="fullwidth">                 
                    <div class="entry">
                          <div class="backimage" style="background-image:url(http://essentialworld.travel/wp-content/uploads/2012/11/Lost-in-Boskenna-Woods-980-V3.jpg); height: 740px;" margin-top: 0px;>
<div style="
     height: 430px;
     width: 400px;
     font-family: Tahoma, Geneva, sans-serif;
     font-size: 18px;
     color: #FFF;
     padding-top: 50px;
     margin-left: 500px;
     background: #999999;
     opacity: 0.9;"
<div>
<div class="floatingtext" style="margin: 20px; opacity: 1.0;">
     <h1 style="color: white;">Some of Our Best Deals are Telephone Only</h1>
To guarantee you reserve the right room at the right price, call now or leave your name and number and we'll call you back!
<div class="clicktocall" style="font-size: 30px; margin-top: 20px; margin-left: 70px">
<a href=”tel:0118 971 4700″>0118 971 4700</a>
</div>
<br>
<div>
<form action="MAILTO:kateg@morna.uk.com" method="post" enctype="text/plain">
<input type="text" placeholder="Name" name="name"><br>
<input type="text" placeholder="Telephone Number" name="mail"><br>
<br />
<input type="submit" class="submit" value="Call Back">

</form>
</div>

</div>

</div></div></div></div>

  
                                                            
          </div><!-- /#main -->
          
    </div><!-- /#content -->